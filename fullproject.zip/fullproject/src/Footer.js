import React , {Component} from 'react';
class Footer extends  Component {
render()
{
    return <div className="container-fluid">
            <div className="row">
                <div className="col-md-12 text-center bg-dark padding50">
                    <h2 className="text-white"> This is from footer</h2>
                </div>
            </div>
        </div>
}

}
export default Footer;

