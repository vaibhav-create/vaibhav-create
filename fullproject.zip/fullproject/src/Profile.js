import React , {Component} from 'react';
class Profile extends Component
{
    render()
    {
        return <div><h3>My Profile</h3></div>
    }
}

export default Profile;